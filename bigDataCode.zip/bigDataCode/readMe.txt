﻿kmeans---------基于Hadoop平台设计的kmeans算法，实现购书用户聚类的功能
test-----------老师给的测试代码，修改配置后用于测试自己的hadoop环境
recommender----用mahout实现的推荐算法，最终按需求生成推荐书总表