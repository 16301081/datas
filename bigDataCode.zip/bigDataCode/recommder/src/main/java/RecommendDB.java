import java.sql.*;
import java.util.List;


public class RecommendDB {
    // MySQL 8.0 以下版本 - JDBC 驱动名及数据库 URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/datas";

    // MySQL 8.0 以上版本 - JDBC 驱动名及数据库 URL
    //static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
//    static final String DB_URL = "jdbc:mysql://192.168.137.224:3306/RUNOOB?useSSL=false&serverTimezone=UTC";

    // 数据库的用户名与密码
    static final String USER = "root";
    static final String PASS = "123456";


    public static void deleteTb() {
        Connection conn = null;
        String sql = "DROP TABLE if exists recommend_tb";
        try {
            // 注册 JDBC 驱动
            Class.forName(JDBC_DRIVER);

            // 打开链接
//            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);

            stmt.close();
            conn.close();
        } catch (SQLException se) {
            // 处理 JDBC 错误
            se.printStackTrace();
        } catch (Exception e) {
            // 处理 Class.forName 错误
            e.printStackTrace();
        } finally {
            // 关闭资源
            try {
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("delete recommend_tb finished!");
    }

    public static void createTb() {
        Connection conn = null;
        Statement stmt = null;
        try {
            // 注册 JDBC 驱动
            Class.forName(JDBC_DRIVER);

            // 打开链接

            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // 执行查询

            stmt = conn.createStatement();
            String sql;
            sql = "CREATE TABLE recommend_tb(uid int,iid int)";
            stmt.execute(sql);
            stmt.close();
            conn.close();
        } catch (SQLException se) {
            // 处理 JDBC 错误
            se.printStackTrace();
        } catch (Exception e) {
            // 处理 Class.forName 错误
            e.printStackTrace();
        } finally {
            // 关闭资源
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException se2) {
            }// 什么都不做
            try {
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("create recommend_tb finished");
    }

    public static void save(List<int[]> items) {
        Connection conn = null;

        try {
            // 加载数据库驱动
            Class.forName("com.mysql.jdbc.Driver");
            // 声明数据库view的URL

            // 建立数据库连接，获得连接对象conn
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            String sql = "insert into recommend_tb(uid,iid)values(?,?)";
            // 创建一个Statment对象
            PreparedStatement ps = conn.prepareStatement(sql);
            for(int i=0;i<items.size();i++){
               for(int []item2:items) {
                // 为sql语句中第一个问号赋值
                ps.setInt(1,item2[0]);
                // 为sql语句中第二个问号赋值
                ps.setInt(2, item2[1]);
                   ps.executeUpdate();
            }

            }




            // 关闭数据库连接对象
            conn.close();


        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            // 关闭资源

            try {
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("save to recommend_tb finished");
    }


    }









