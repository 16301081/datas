import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import org.apache.commons.lang.ObjectUtils;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.model.jdbc.MySQLJDBCDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.JDBCDataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;
import org.apache.mahout.cf.taste.similarity.precompute.example.GroupLensDataModel;



public class BaseUser {
    static final int USER_NUM=100;
    static final int RECOMMEND_NUM=5;


    public static void main(String[] arg)throws Exception{
//        File file = new File("src/main/java/1.txt");
//        FileDataModel dataModel = new FileDataModel("1.txt")
//
//
//
//        UserSimilarity similarity=new PearsonCorrelationSimilarity(dataModel);
//        UserNeighborhood userNeighborhood=new NearestNUserNeighborhood(100,similarity,dataModel);
//        Recommender recommender=new GenericUserBasedRecommender(dataModel,userNeighborhood,similarity);
//        List<RecommendedItem> recommendedItemList=recommender.recommend(1,1);
//        System.out.println("使用基于用户的协同过滤算法");
//        System.out.println("为用户4推荐的10个物品");
//        for(RecommendedItem recommendedItem : recommendedItemList){
//            System.out.println(recommendedItem);
//        }



//
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setServerName("localhost");
        dataSource.setUser("root");
        dataSource.setPassword("123456");
        dataSource.setDatabaseName("datas");


        List <int []> recommend_List= new ArrayList<int[]>();


        JDBCDataModel dataModel = new MySQLJDBCDataModel(dataSource, "data", "uid", "iid", "pre", "time");

        DataModel model = dataModel;
        UserSimilarity similarity=new PearsonCorrelationSimilarity(model);
        UserNeighborhood neighborhood=new NearestNUserNeighborhood(2,similarity,model);

        Recommender recommender=new GenericUserBasedRecommender(model,neighborhood,similarity);



//        List<RecommendedItem> recommendations = recommender.recommend(89, 4);
//        for (RecommendedItem recommendation : recommendations) {
//            System.out.println(recommendation+"    1212121212121");
//            long t = recommendation.getItemID() ;
//
//            System.out.println(t);
//
//        }

        RecommendDB.deleteTb();
        RecommendDB.createTb();
int i;
for( i=1;i<=USER_NUM;i++) {
    long start = System.currentTimeMillis();
    List<RecommendedItem> recommendations = recommender.recommend(i, RECOMMEND_NUM);
    int [] item =new int[2];
    System.out.println("----------------------------user："+i + "---------------------------");
    for (RecommendedItem recommendation : recommendations) {
        System.out.println(recommendation );

        long tmp = recommendation.getItemID();
        int tmp1 = (int)tmp;
        item[0]=i;
        item[1]=tmp1;


    }
    long end = System.currentTimeMillis();
    System.out.println("---------time :"+(end-start)+"------------------");
    System.out.println("----------------------------------------------------------------");
    System.out.println();
    recommend_List.add(item);
}

     long start1= System.currentTimeMillis();
      RecommendDB.save(recommend_List);
        long end1= System.currentTimeMillis();
        System.out.println("-----------time :"+(end1-start1)+"------------------");

   }

}